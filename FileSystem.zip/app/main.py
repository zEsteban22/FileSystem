from Vista import *;

if __name__ == "__main__":
    V = Vista()
    V.mainloop()